
If you want support for the built-in browser in Linux, please install Mozilla XULRunner.
A lot of distributions ship with this software these days, so we used this as the default configuration option.
If you want you can change the location in spoon.sh with the MOZILLA_FIVE_HOME environment variable.

x86_64 notes:

This build requires a 64 bit JVM. It will not run with a 32 bit JVM.
You can for example download Sun 64 bit 1.5 JVM for AMD64. Note that
Sun 1.4.2 JVM for AMD64 is 32 bit and cannot be used to run this build. 

